# Figure Index

- **F01_KTH_group_coverage**: Nominal vs observed simultaneous coverage of raw LAC. [GENERATED]
- **F02_KTH_95pct_prediction_set_size**: 95% frozen group-conformal set sizes for LAC/APS/RAPS. [GENERATED]
- **F03_KTH_seven_architecture_ECE**: Seven original-style versus corrected calibration policy ECE results. [GENERATED]
- **F04_RAD_DAR_raw_baseline_performance**: Raw locked-test accuracy and Macro-F1 for six baseline approaches. [GENERATED]
- **F05_RAD_DAR_efficiency_tradeoff**: Deterministic CNN parameters and measured same-hardware batch latency. [GENERATED]
- **F06_RAD_DAR_grouping_support**: Class-bearing filename and candidate group counts, not physical sessions. [GENERATED]
- **F07_RAD_DAR_selective_accuracy**: Selective accuracy versus achieved acceptance from frozen test cutoffs. [GENERATED]
