# Reviewer/Client Coding-Comment Response — Five Issues

This is a scientific response summary grounded in frozen results. **Methodologically addressed** does not mean external reviewer acceptance or universal guarantees.

## Comment #4 — Conformal group-calibration

**Correction:** Revised KTH split with 19 conformal calibration measurement groups (originally 9, insufficient for a finite 95% group-maximum quantile), five retrained models, precommitted group-max LAC/APS/RAPS scores, 12 policy evaluations, 17-group test. **Observed raw LAC nominal-95% coverage: 16/17 = 94.12%**; mean prediction-set size 2.335/4. Coverage guarantee is **marginal under exchangeability of the measurement-group scoring units**, not unconditional or class-conditional.

**Status:** Methodological correction complete in stated group-exchangeable scope. No claim of prospectively blind testing.

## Comment #5 — Abstention chosen from test

**Correction:** Replaced test-ranked thresholds with six calibration-only cutoffs frozen before evaluation; the test acceptance and error analyses were independently replayed.

**Status:** Fully addressed for retrained computational scope.

## Comment #7 — Temperature scaling worsened seven model ensembles

**Correction:** Trained and audited seven architectures × five seeds and compared raw, original member-scaled and eight-group LOGO-calibration-selected policies. Signed checkpoint and test-score replays passed.

**Status:** Seven-architecture retrained-model remedy complete. Original historical model weights were unavailable; exact causal diagnosis of those specific historical checkpoints remains unverified. Retrospective evaluation, not prospective blind validation.

## Comment #9 — Missing ResNet18, MobileNetV3, MC Dropout

**Correction:** Added six independent ResNet/MobileNet runs; MC Dropout stochastic inference (3 standard CNN backbones ×30 draws), same calibrated/locked-test cohort and efficiency descriptors. Do not describe estimated 90-pass MC latency as measured end-to-end runtime.

**Status:** Fully addressed in stated RAD-DAR proxy-family split scope.

## Comment #3 — RAD-DAR group labels / confounding / independent sessions

**Correction:** Audited all 17,485 labeled files; found 80 entirely class-pure candidate groups; constructed an alternative four-way filename-family-disjoint sensitivity split with 51 families, zero proxy-group overlaps; retrained 9 CNN seed models, froze calibration, evaluated 2,626 test observations, and assessed class-conditional proxy-family behavior and descriptive resampling.

**Unresolved evidence:** The public dataset files did not supply **validated physical recording-session IDs** or an authoritative source mapping individual files to sessions. Filename families and candidate groups are not equivalent to genuine independent acquisitions; class–proxy association remains strong. Further epochs or arbitrary regrouping cannot reconstruct absent acquisition metadata. The manuscript may accurately claim **family-disjoint sensitivity analysis**, but not proven **independent-session generalization**. Obtaining author-provided session mapping would be needed to assess that stronger claim.

**Status:** Computational sensitivity work completed; strict physical-session independence remains partial/not established **because of dataset provenance**, not because of failed model training.
