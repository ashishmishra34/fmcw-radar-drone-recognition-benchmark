# Methods and Main Results — Reported Frozen Evidence

## Study structure and verification

Original 31-cell Kaggle workflow (all cells completed) evaluated **two distinct radar datasets** with separate architectures and labels. We did not pool class systems or sensors. All content below comes from frozen tables created in those cells; figures are visualizations only, not reanalysis or new tuning.

### KTH / SAAB (77 GHz)

- Original: **75,868 segments** from **130 source measurement IDs**; four classes.
- Comment #4 remediation: **70 train / 16 validation / 8 temperature-fit / 19 conformal-fit / 17 locked-test groups**. Five Compact Attention CNN checkpoints independently retrained on revised train-only inputs; temperature and conformal scores fitted on disjoint held-out groups.
- Group-max conformal score: 95% threshold rank **19/19**; this supplies finite group-level thresholds under the stipulated marginal exchangeability assumptions.
- Primary 95% raw LAC: **16/17 = 94.12%** complete test groups covered, segment coverage **99.98%**, mean set size **2.335/4**. Empirical performance is descriptive, not a standalone proof of exchangeability.
- APS/RAPS often produce near-complete four-class sets; include set-size comparison before claiming useful selective prediction.
- Comment #7: seven architectures × five retrained seeds = **35 checkpoints**. Eight-group leave-one-group-out calibration selected per-architecture policies. All raw, original member-scaled, and calibration-only selected ECE/NLL should be reported (Table T05). Historical checkpoint-level root cause remains unresolved.
- Comment #5: abstention thresholds were selected on calibration data before test scores; realized acceptance is reported without test-based cutoff changes (Table T07).

### RAD-DAR (8.75 GHz)

- Source: **17,485 matrix samples**; Cars / Drones / People; source values stored as 11×61 matrices.
- Grouping audit: **80 class-pure candidate group proxies**, **51 filename-family proxies**; the constructed four-way proxy-family split had zero overlapping families/candidate groups between partitions.
- Corrected sensitivity allocation: **10,497 train / 2,615 validation / 1,747 calibration / 2,626 test**.
- Three original CNN architectures × three seeds (9 checkpoints) were retrained and locked-test evaluated. Six additional ResNet18/MobileNetV3-Small checkpoints were trained (3 seeds each); MC Dropout reused three StandardCNN backbones with 30 draws per seed.
- Group sensitivity and classwise summaries are descriptive for filename-derived units; no independent physical recording-session metadata or mapping was available. **This limits generalization claims** regardless of code correctness.
- Model comparisons below use **raw T=1** on the corrected n=2,626 test cohort; scaled policies are retained in full Table T08.

| Model | Raw accuracy | Macro-F1 | 15-bin ECE |
|---|---:|---:|---:|
| standard cnn | 91.70% | 0.9134 | 0.01710 |
| tiny cnn | 92.99% | 0.9263 | 0.01411 |
| depthwise cnn | 94.67% | 0.9446 | 0.02284 |
| ResNet-18 | 94.33% | 0.9400 | 0.02826 |
| MobileNetV3-Small | 89.72% | 0.8926 | 0.07235 |
| MC Dropout | 91.66% | 0.9129 | 0.01323 |

## Figures

- F01–F02: KTH nominal group coverage versus observed coverage, and prediction-set informativeness.
- F03: Seven-architecture raw/original/selected ECE.
- F04: RAD-DAR test accuracy and Macro-F1.
- F05: RAD-DAR measured deterministic-model latency vs parameter count (batch=128, hardware-specific; not deployed runtime).
- F06: Per-class test proxy-group support; NOT session IDs.
- F07 (when available): frozen-policy selective accuracy/acceptance.

## Reproducibility and scientific boundaries

Results and citations should be checked in the full separately shared 31-cell Kaggle notebook. The ZIP includes source SHA receipts for extracted tables. This export performs no training, inference, tuning, and no changes to any scientific source. The original historical test had been examined before later remediation work, so corrected methods should **not** be described as a fresh prospectively blinded evaluation.
