# Cell 29/31 — Comment #4 Final Group-Conformal Remediation

**Method-level coding/reviewer determination:** FULLY_ADDRESSED_GROUP_CONFORMAL_METHOD_CORRECTION_WITH_STANDARD_EXCHANGEABILITY_ASSUMPTION.

- **Primary predefined analysis:** raw five-seed Compact Attention ensemble; group-maximum LAC score; 19 distinct conformal-calibration measurements; 95% threshold at the 19th of 19 ranks.
- **Locked 17-measurement test evaluation:** 16/17 groups had **all** constituent segments' true labels in their sets (94.12%); segment-level empirical coverage 99.98%; mean set size 2.335 out of four classes; 0 empty segment-level sets.
- 12 fixed raw/scaled LAC/APS/RAPS results are reported in the attached result tables. Numerical near-1 rounding sensitivity of APS/RAPS is audited **without** changing frozen inclusion rules.
- The standard split-conformal **marginal simultaneous within-new-measurement** coverage statement depends on exchangeability of the 19 calibration measurement groups and a future test measurement group and group-maximum scoring fixed independently from those data. Exchangeability is an assumption, **not independently proven** by the measurement IDs or empirical coverage.
- These results do **not** establish class-conditional coverage, independent physical sessions, or unconditional coverage without assumptions. Test groups were held out from the revised 70-group retraining and 19-group fitting but had been examined in earlier work, hence this is a **retrospective remediation**, not a fresh prospective blind validation.
- A finite 95% group-score quantile does not imply useful small sets; APS/RAPS may be nearly vacuous and must be reported with actual set sizes.
- If a reviewer demands demonstrated exchangeability or prospective external confirmation rather than a standard assumption-based group-conformal method, that stronger claim remains unresolved by these data.
