# Final 31-Cell Scientific Response — SHR-ZHR-1387

## Comment #3 — RAD-DAR grouping provenance and leakage

The initial grouping proxies were identified as class-confounded (80 candidate groups, all class-pure).
A prespecified alternative sensitivity analysis used 51 label-blind filename-derived families across four nonoverlapping partitions, with 10,497 train, 2,615 validation, 1,747 calibration and 2,626 locked-test files.
Nine original-protocol CNN seed models were retrained; calibration policies were frozen without test optimization. Three architectures and three additional baseline approaches were evaluated on the corrected test cohort.
The held-out test contains 9 filename families, 14 candidate groups, and class counts Cars=861, Drones=760, People=1005.
Class-conditional proxy-family and candidate-group error summaries and descriptive resampling were produced and verified independently (Cell21). The resampling ranges are **not** confidence intervals for independently acquired radar sessions.

### Reviewer decision and strict limitation
The requested **class-confounding diagnosis, alternative leakage-aware proxy-disjoint sensitivity design, retraining and evaluation** have been completed and reproducibly audited.
**However, this is not independently verified recording-session generalization**. Neither source filenames nor candidate group codes establish physical acquisition sessions, and no authoritative session mapping was available. This stronger claim remains PARTIAL/UNSUPPORTED.
The original and family-disjoint sensitivity splits use different sample cohorts; their test scores should be presented separately, never paired as if matched.

## All five coding-comment conclusions

### #4 — Group-conformal prediction
- Computational correction: **FULLY_IMPLEMENTED_AND_REPLAYED**
- Adequacy: **FULLY_ADDRESSED_METHOD_CORRECTION_CONDITIONAL_ON_EXCHANGEABILITY**
- Evidence: 19 group maxima for calibration; 95% rank=19/19; locked group coverage=16/17; no test tuning
- Boundary: Empirical exchangeability/prospective blind external validation NOT established

### #5 — Abstention thresholds
- Computational correction: **FULLY_IMPLEMENTED_AND_REPLAYED**
- Adequacy: **FULLY_ADDRESSED_RETRAINED_COMPUTATIONAL_SCOPE**
- Evidence: Cell07 calibration-only thresholds and Cell08 frozen test; Cell25 six-cutoff independent replay
- Boundary: Observed test acceptance can differ from nominal calibration targets

### #7 — Seven-model temperature scaling
- Computational correction: **FULLY_IMPLEMENTED_AND_REPLAYED**
- Adequacy: **FULLY_ADDRESSED_RETRAINED_35_MODEL_METHODOLOGY**
- Evidence: Cell30: 35 checkpoint/test SHA receipts; 7 LOGO policies; 21 raw/original/corrected test rows
- Boundary: Exact original historical checkpoint cause remains unverified; retrospective prior test knowledge

### #9 — ResNet18, MobileNetV3 and MC Dropout
- Computational correction: **FULLY_IMPLEMENTED_AND_REPLAYED**
- Adequacy: **FULLY_ADDRESSED_NAME_FAMILY_PROXY_TEST_SCOPE**
- Evidence: Cells22-24 six new seed checkpoints, MC 3x30, 11 frozen test metrics replayed
- Boundary: MC latency is estimated, not measured deployment; verified physical session evaluation absent

### #3 — RAD-DAR class-confounded grouping
- Computational correction: **FULLY_IMPLEMENTED_PROXY_FAMILY_DISJOINT_SENSITIVITY**
- Adequacy: **ADEQUATELY_ADDRESSED_AS_DISCLOSED_PROXY_SENSITIVITY__PARTIAL_FOR_PHYSICAL_SESSION_GENERALIZATION**
- Evidence: Cells15-21,24: 17,485 files; 80 class-pure candidate groups; 51 family proxies; 0 overlaps; new test=2,626 and 9 families
- Boundary: Authentic physical recording session IDs unavailable; filename family not verified acquisition session

## Essential manuscript reporting controls
- Do not replace historical RAD-DAR test n=2,757 with corrected *sensitivity* test n=2,626 without explicitly labeling different cohorts.
- In KTH, distinguish nominal 95% marginal simultaneous group coverage (under measurement-group exchangeability) from observed 16/17 = 94.12%. Report prediction-set size and nearly vacuous APS/RAPS sets.
- Calibration policies are retrospective; test results were previously known, even though no policy was refit on the locked test in the remediation cells.
- Report all seven KTH raw/original-member/corrected ECE comparisons. Do not assert exact cause of historical model failure without the lost weights.
- Do not describe filename families as real acquisition sessions, claim rigorous independent-session generalization, or report descriptive proxy-resampling as formal session confidence intervals.
- Keep baseline parameter counts and measured inference timings separate from the estimated MC-Dropout 90-pass runtime.
- This final reviewer package is a code-and-evidence audit, not a guarantee that an external reviewer will formally accept every claim.

## Status
FIVE/FIVE requested computational workflows completed. Four comments have adequate method-level corrections in their qualified scope. Comment #3 has a completed family-proxy sensitivity correction, but the stronger physical session-independence claim is **not established**.
All source scientific files were treated read-only; no model training, fitting, resplitting, test-time optimization or manuscript edits occurred in Cell31.
