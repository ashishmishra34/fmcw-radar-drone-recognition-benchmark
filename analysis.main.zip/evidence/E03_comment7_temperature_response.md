# Cell 30 — Client #7 Temperature Scaling: Final Evidence-Based Reply

## Scope and correction
We investigated the worsening of expected calibration error and negative log-likelihood under member-specific temperature scaling by training 35 new KTH models (seven architectures; five seeds each).
For each architecture, five predefined calibration policies were compared through eight-measurement-group leave-one-group-out NLL, with equal weight across held-out measurement groups. The group-held-out winner was frozen before locked-test inference. The original member-specific policy, raw T=1 baseline and calibration-selected policy are all reported rather than only favorable outcomes.

## Results and interpretation
Original-style member temperature scaling worsened test ECE on 7/7 retrained architecture ensembles. Calibration-only selected policies lowered locked-test ECE versus original-style scaling on 7/7 ensembles (descriptive, not an optimization objective).
Member-wise NLL optimization is not equivalent to calibrating an ensemble or guaranteeing lower test ECE. Shift in group/class composition, including zero Reflector groups in the eight-group temperature-fit cohort, is a documented risk, but its individual causal contribution was not identified.

## Limits and claims not permitted
This is a retrospective analysis because earlier test results were already inspected in Cell 09, even though the Cell 14 implementation froze its new calibration policies before locked-test inference.
The original historical checkpoints were unavailable; the new 35-model results are an independently trained replication, not proof of the exact root cause in the original seven historical ensembles.
No claim of a universally improved test ECE, a prospectively blinded benchmark, or an exact reconstruction of missing historical model weights is warranted.

## Reviewer status
- Model-and-calibration methodology corrected for the new 35-model, seven-architecture experiment: **FULLY ADDRESSED in this defined computational scope**.
- A request to prove the exact historical checkpoint-level cause cannot be fully addressed without the original checkpoints: **PARTIAL in that stronger historical scope**.
- Manuscript must use all seven rows in the signed comparison and explain raw, original-member and calibration-selected results.

## Reproducibility
No neural-network training, temperature fitting, policy selection, test-data tuning or original evidence overwriting was performed in Cell 30.
