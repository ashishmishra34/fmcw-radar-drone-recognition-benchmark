# Reproduction map: the complete 31-cell notebook is supplied separately

**Cells 1–3 — Setup/source:** Kaggle environment and original KTH/RAD-DAR data provenance.

**Cells 4–8 — KTH initial uncertainty:** Compact-attention five-seed baseline, original segment conformal diagnostics, and calibration-only abstention cutoffs; locked test evaluation (comments #4 and #5).

**Cells 9–14 — KTH temperature diagnosis:** Seven architectures with five newly trained models each (35 total), frozen eight-group leave-one-measurement-out calibration policies and raw/original-scaled/selected locked-test comparisons (comment #7).

**Cells 15–17 — RAD-DAR audit/split:** Group-label-confounding audit on 17,485 matrices, four-way disjoint filename-family sensitivity split, train-only normalization (comment #3).

**Cells 18–21 — RAD-DAR evaluation:** Nine three-architecture/three-seed models retrained; temperatures/abstention thresholds frozen on calibration before n=2,626 test; classwise proxy-family sensitivity and descriptive resampling.

**Cells 22–24 — Additional baselines:** ResNet-18 and MobileNetV3-Small (three seeds each) plus 3×30 MC Dropout inference; same test cohort, latency/parameter comparisons (comment #9).

**Cell 25 — First comprehensive reviewer QA:** Independent replays with caveats.

**Cells 26–29 — KTH corrected group conformal:** Precommitted 70/16/8/19/17 measurement-group design; five-seed retraining; 19-group group-max LAC/APS/RAPS thresholds; 17-group held-out assessment with group vs segment coverage separated (comment #4).

**Cells 30–31 — Final verified QA:** Seven-architecture temperature replay and all five comments' evidence-based statuses, including unresolved physical-session metadata (comments #7 and #3).

**Final export cell (this notebook):** Reads only source results and signed manifests, creates compact figures/tables/reviewer reports and hashes. No model training, inference, split changes or policy tuning.

## Reproduction boundaries

The ZIP is an **evidence companion**, not a standalone training replica: it excludes full 31-cell notebook, model weights, logits and raw radar data. The analyst should provide the **complete executed Kaggle notebook separately**. Group-marginal conformal results assume exchangeable measurement groups; RAD-DAR filename families are not validated independent recording sessions. Original historical KTH weights were unavailable, and calibration remediation is retrospective rather than prospectively blind.
