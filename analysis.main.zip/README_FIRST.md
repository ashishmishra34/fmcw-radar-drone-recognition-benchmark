# SHR-ZHR-1387 | Compact Client Analysis Evidence Package

**Study:** Uncertainty-Aware Lightweight Deep Learning for Drone Recognition: A Two-Dataset FMCW Radar Benchmark of Classification, Calibration, Robustness, and Efficiency.

This archive is the **client-facing results and evidence companion** to the separately exported **full Kaggle 31-cell notebook**. It contains copied, SHA-recorded original analytical tables, graphical summaries plotted directly from those tables, fixed protocols and audit reports. It is **not** a standalone training reproduction: raw radar datasets, model weights and large predictions are intentionally omitted.

## Read these first

1. `README_FIRST.md` — scope, workflow and package contents.
2. `CLIENT_COMMENT_RESPONSE.md` — five issues, work completed, and explicit limitations.
3. `METHODS_AND_RESULT_SUMMARY.md` — methods, exact reported metrics and plot interpretation.
4. `figures/` — publication-ready PNG and editable/vector SVG charts.
5. `tables/` — original signed results in CSV.
6. `evidence/` — source scientific protocols and signed final reviewer reports.
7. `SHA256_SOURCE_INVENTORY.csv` — original source SHA256 checksums; `PACKAGE_CONTENTS_SHA256.csv` — all included member hashes.

## Five client coding comments: scope-accurate scientific statuses

| Comment | Topic | Final reviewed status |
|---|---|---|
| #4 | Group-conformal prediction | FULLY_ADDRESSED_METHOD_CORRECTION_CONDITIONAL_ON_EXCHANGEABILITY |
| #5 | Abstention thresholds | FULLY_ADDRESSED_RETRAINED_COMPUTATIONAL_SCOPE |
| #7 | Seven-model temperature scaling | FULLY_ADDRESSED_RETRAINED_35_MODEL_METHODOLOGY |
| #9 | ResNet18, MobileNetV3 and MC Dropout | FULLY_ADDRESSED_NAME_FAMILY_PROXY_TEST_SCOPE |
| #3 | RAD-DAR class-confounded grouping | ADEQUATELY_ADDRESSED_AS_DISCLOSED_PROXY_SENSITIVITY__PARTIAL_FOR_PHYSICAL_SESSION_GENERALIZATION |

### Important interpretation boundaries

- **#3 RAD-DAR:** The sensitivity split is nonoverlapping across **filename-derived proxy families**, not independently verified physical recording sessions. Original class/group confounding remains. Physical session generalization must not be claimed.
- **#4 KTH conformal:** Nominal 95% group-marginal coverage is conditional on exchangeable measurement units. Observed primary 95% LAC simultaneous coverage is **16/17 = 94.12%**; nominal target and observed coverage differ.
- **#7 KTH calibration:** 35 newly retrained models were assessed retrospectively; unavailable historical checkpoint weights and exact historical causal diagnosis were not recovered.
- **#9 efficiency:** MC Dropout batch latency is **estimated**, not directly measured as deployed end-to-end runtime.
- Historical and alternative RAD-DAR test cohorts are different. Do not merge or pair their individual observations as if matched.

## Compact-package omissions (intentional)

No original radar arrays, 17,485-row filename inventory, sample-level model logits, 15+ model checkpoint binaries, dataset downloads, duplicated full notebooks, intermediate caches, or raw source ZIPs. Send the **full 31-cell Kaggle notebook separately** for executable reproduction with original datasets.
